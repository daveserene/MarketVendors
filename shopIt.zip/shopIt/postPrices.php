<?php

$servername = "localhost";
$username = "vendor";
$password = "vendor";
$dbname = "shopIt";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 


$mark = 0;			
$sql = "";
$index = 0;
while($index == 0) {
	
	if(isset($_POST["vdr-".$mark])){
		$sql = $sql . "INSERT INTO Commodity (commodityName, unit, price, vname, market, cid) VALUES ('".$_POST["cty-".$mark]."', '".$_POST["uty-".$mark]."', '".$_POST["pcs-".$mark]."', '".$_POST["vdr-".$mark]."', '".$_POST["mkt-".$mark]."', NULL);";
      $mark++;	
	}else {
		break;
	}
 
}

if ($conn->multi_query($sql) === TRUE) {
    
    $j = array('name' =>"New records created successfully");
} else {
    
    $j = array('name' =>"Error: " . $sql . "<br>" . $conn->error);
    
}
$conn->close();
        
        
                
        
        echo json_encode($j);
        
        
/*
    mysql_select_db('shopIt');

for($index = 0; $index < ) {

}
$sql = "INSERT INTO 'shopIt'.'Commodity' ('commodityName', 'unit', 'price', 'vname', 'market', 'cid') VALUES ('".Peas."', '".per kg."', '".2800."', '".charles."', '".Bugolobi."', NULL);";
   
   mysql_query("");
   printf("Last inserted record has id %d\n", mysql_insert_id());*/

?>