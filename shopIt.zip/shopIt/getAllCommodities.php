 
<?php
header('Cache-Control: no-cache, must-revalidate');
header('Content-type: application/json');

$connection = mysql_connect('localhost','vendor','vendor');

if($connection){
  $db = mysql_select_db('shopIt');
  if(!$db){ 
    print 'Failed to select shopIt dB';
  }else{
    $result = mysql_query('select * from Commodity');
    
    if($result && mysql_num_rows($result)){
      $rows = array();
      $vals = array();
      $index = 0;
      
      while($r = mysql_fetch_assoc($result)) {
        
        $rows['cty'] = $r['commodityName'];
        $rows['unit'] = $r['unit'];
        $rows['price'] = $r['price'];
        $rows['vname'] = $r['vname'];
        $rows['mkt'] = $r['market'];

        $vals["item".$index] = $rows;
        $index++;      
      
      }
      
      $jsonstring = json_encode($vals);    
      
      echo $jsonstring;      
    }
    else {
      echo json_encode("No New Data");
    } 

  }
  
}else{
  print 'failed to connect to database. \n';
}

?>
 
