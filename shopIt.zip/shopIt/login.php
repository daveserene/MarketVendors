<?php
header('Cache-Control: no-cache, must-revalidate');
header('Content-type: application/json');

$servername = "localhost";
$username = "vendor";
$password = "vendor";
$dbname = "shopIt";

// Create connection
$connection = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

    $sql = "select * from Vendor where name = '".$_POST['username']."' and password = '".$_POST['password']."';";
    

$result = $connection->query($sql);

if ($result->num_rows > 0) {

$mkt = "";    
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $mkt = $row["market"];
    }

    $rows = array("status"=>"success", "market"=>$mkt);
    echo json_encode($rows);    
    
} else {
 $rows = array("status"=>"fail");
    echo json_encode($rows);

  }

?>