<?php

$servername = "localhost";
$username = "vendor";
$password = "vendor";
$dbname = "shopIt";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "INSERT INTO Vendor (name, password, market) VALUES ('".$_POST["na"]."', '".$_POST["pa"]."', '".$_POST["ma"]."');";	


if ($conn->query($sql) === TRUE) {
    
    $j = array('status' =>"success");
} else {
    
    $j = array('status' =>"Error: " . $sql . "<br>" . $conn->connect_error);
    
}
$conn->close();
        
        
        echo json_encode($j);
    
?>